package jun23;

class FloatEx1 {
	public static void main(String[] args){
		float var1 = (float)3.4;
		System.out.println("var1�� �� : " + var1);
	}
}