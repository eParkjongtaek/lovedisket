package jun23;

class FloatEx2 {
	public static void main(String[] args){
		float var1,var2;
		var1 = 3.4f;
		var2 = 550;
		System.out.println("var1�� �� : " + var1);
		System.out.println("var2�� �� : " + var2);
	}
}












