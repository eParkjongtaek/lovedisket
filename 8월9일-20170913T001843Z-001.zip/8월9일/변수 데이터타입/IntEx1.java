package jun23;

class IntEx1 {
	public static void main(String[] args){
		byte var1 = (byte)129; //�ս�
		System.out.println("var1�� �� : " + var1);
	}
}