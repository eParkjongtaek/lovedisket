package jun23;

class IntEx3 {
	public static void main(String[] args){
		byte var1 = (byte)128;
		short var2 = (short)32000L;
		int var3 = (int)550f;
		System.out.println("var1�� �� : " + var1);
		System.out.println("var2�� �� : " + var2);
		System.out.println("var3�� �� : " + var3);
	}
}